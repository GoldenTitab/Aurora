import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:home_widget/home_widget.dart';

import '../../core/utils/persian_numbers.dart';
import '../models/home_items.dart';
import '../providers.dart';
import '../../core/i18n/lang.dart';

Future<void> refreshHomeWidget(WidgetRef ref) async {
  try {
    final cw = ref.read(continueWatchingProvider);
    final airing = ref.read(weeklyAiringProvider).valueOrNull ?? const [];

    final ContinueWatchItem? top = cw.isNotEmpty ? cw.first : null;

    var todayCount = 0;
    final today = DateTime.now().weekday;
    for (final d in airing) {
      if (d.weekday == today) {
        todayCount = d.items.length;
        break;
      }
    }

    final String title;
    final String sub;
    if (top == null) {
      title = tr('continue_watching');
      sub = tr('no_episodes_started_yet');
    } else {
      final nextEp = top.lastEpisode + 1;
      final total = top.totalEpisodes;
      title = top.franchiseTitleFa;
      sub = tr('episode_2', [
        toFa(nextEp),
        total > 0 ? tr('of', [toFa(total)]) : '',
        top.entryTitle,
      ]);
    }

    await HomeWidget.saveWidgetData<String>('cw_title', title);
    await HomeWidget.saveWidgetData<String>('cw_sub', sub);
    await HomeWidget.saveWidgetData<int>('airing_today', todayCount);

    await HomeWidget.updateWidget(
      androidName: 'AuroraWidgetProvider',
      iOSName: 'AuroraWidget',
    );
  } catch (_) {}
}
